# pca
Programação de Computadores e Algoritmos

Repositorio das listas de exercícios
