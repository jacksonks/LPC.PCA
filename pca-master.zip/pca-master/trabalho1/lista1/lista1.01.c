/*
 Programacao de Computadores e Algoritmos
 Trabalho 1
 Questao 1.1
 
Equipe:
	Fulano
	Beltrano
	Sincrano
 */

#include <stdio.h>

int main(int argc, const char *argv[])
{
	printf ("O primeiro programa a gente nunca esquece\n");
	return 0;
}
