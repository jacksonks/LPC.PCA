#include <stdio.h>

/*
Programacao de Computadores e Algoritmos / Laboratorio de Programacao de Computadores

Questao 08 da Lista 1

Equipe:
	Ewerton Petillo	
	Jackson Kelvin
	Gabriel Faraco
	Lucas Vinicius

*/


int main(int argc, const char  *argv[])
{
	printf("CCCCC\n");
        printf("C\n");
        printf("C\n");
        printf("CCCCC\n");
        return 0;
}
