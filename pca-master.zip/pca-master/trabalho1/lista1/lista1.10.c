/*
 * Programa de Computadores e Algoritmos
 * Trabalho 1
 * Questoa 1.10
 *
 * Equipe: 
 *         Delrik
 *         Elisabeth
 *         Hermamm
 *         Luis
 *         Luana
 *         Richardson
 *
 */

#include <stdio.h>

int main(int argc, const char *argv[])
{
	printf("       X\n      XXX\n     XXXXX\n    XXXXXXX\n   XXXXXXXXX\n  XXXXXXXXXXX\n XXXXXXXXXXXXX\nXXXXXXXXXXXXXXX\n      XX\n      XX\n     XXXX\n");
	
	return 0;
}
