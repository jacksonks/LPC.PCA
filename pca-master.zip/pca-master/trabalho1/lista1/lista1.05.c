/* 
 *   Programação de Computadores e Algoritmos
 *   Trabalho 1
 *   Questão 1.1
 *   Equipe: Benjamin Borges
 *   Davi Tavares
 *   Manoel Souza 
 *   Lucas Botinelly
 *   Jackson Gomes
 *   Robson Borges
 *   Grupo 1 - 
 */

#include <stdio.h>

int main(int argc, const char *argv[])
{
	printf("\nAo professor:\n");
	printf("	Esperamos dessa disciplina:\n");
	printf("	1 - Compromisso do primeiro dia de aula! \n");
	printf("	2 - Dedicação no preparo das aulas\n");
	printf("	3 - Desafio que nos motive\n");
	printf("	4 - Inovação do pensamento para resolvermos problemas\n");
	return 0;
}
