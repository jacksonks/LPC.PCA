#include<stdio.h>

int main(int argc, const char *argv[])
{
	printf("Certo.\n");

	return 0;
}
