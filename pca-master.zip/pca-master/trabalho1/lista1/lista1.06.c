/* 
 Programação de Computadores e Algoritmos
 Trabalho 1
 Questão 1.1
 Equipe: Benjamin Borges
	 Davi Tavares
	 Manoel Souza 
	 Lucas Botinelly
	 Jackson Gomes
	 Robson Borges
Grupo 1 - 
 */

#include<stdio.h>

int main(int argc, const char *argv[])
{
	printf("XXXXX\nX   X\nXXXXX\n");
	return 0;
}

