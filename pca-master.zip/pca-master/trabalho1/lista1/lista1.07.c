#include <stdio.h>

/* 
Questao 7 da Lista 1

Programacao de Computadores e Algoritmos / Laboratorio de Programacao de Computadores

Equipe: 
	Jackson Kelvin de Souza
	Ewerton Rodrigo Nunes Petillo
	Gabriel Faraco
	Lucas Frota

*/

int main(int argc, const char* argv[])
{
	printf("ALUNO(A)       NOTA\n");
        printf("========       =====\n");
        printf("ALINE           9.0\n");
        printf("MÁRIO           DEZ\n");
        printf("SÉRGIO          4.5\n");
        printf("SHIRLEY         7.0\n");
	return 0;
}
