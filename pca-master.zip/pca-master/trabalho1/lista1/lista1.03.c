/*
Programação de Computadores e Algoritmos
Trabalho 1
Questão 1.3

Equipe:
	Paulo Marinho
	Sergio Pinheiro
	Wilson Calixto
	Andressa Moreira
	Rodrigo [TADS]
*/	

#include <stdio.h>

int main(int argc, const char *argv[])
{
	printf("Voce não vai passar em laboratorio!\n");
	printf("Se voce for escolhido sua equipe vai tirar zero!\n");
	printf("Voce não vai conseguir superar isto!\n");
	printf("Voce não vai terminar a lista no prazo.\n");

	return 0;
}
