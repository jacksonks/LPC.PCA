/*
Programação de Computadores e Algoritmos
Trabalho 1
Questão 1.9

Equipe:
	Evandro Fernandes
	Wilson Neto
	John Lucas
	Jessica Kelly
	Fernando Antonio
	Jailson Pereira
	Juliany Raiol
	Raí Santos*/

#include <stdio.h>

int main(int argc, const char *argv[])
{
	printf("Cadastro do Cliente\n");
	printf("0-Fim\n");
	printf("1-Inclui\n");
	printf("2-Altera\n");
	printf("3-Excluir\n");
	printf("4-Consultar\n");
	return 0;
}
