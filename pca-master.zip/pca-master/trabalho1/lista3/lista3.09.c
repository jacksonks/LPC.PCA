/*

Programacao de Computadores e Algoritmos 

Trabalho1

questão 3.9

Equipe: Evandro Fernandes
	Fernando Antonio
	Jailson Pereira
	Jessica Kelly
	Jhon Lucas
	Juliany Raiol
	Wilson Neto
	Raí Santos
*/

#include <stdio.h>

int main(int argc, const char *argv[])
{
	int i;
	for(i=1;i<=50;i++)
	{
		if( (i%2) ) printf("%d\n",i);
	}
	return 0;
}
