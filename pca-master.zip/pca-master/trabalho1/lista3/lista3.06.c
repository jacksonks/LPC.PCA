/*
Programação de computadores e Algoritmos
Trabalho 1
Questão 3.06

Equipe:
	Evandro Fernandes
	Wilson Neto
	John Lucas
	Jessica Kelly
	Fernando Antonio
	Jailson Pereira
	Juliany Raiol
	Raí Santos
*/

#include <stdio.h>

int main(int argc, const char *argv[])
{
	int n;
	for (n=1; n<20; n++)
	{
		printf("%d ",n);
	}
    	printf("\n");
    	return 0;
}
