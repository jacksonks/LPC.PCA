void walking(char maze[23][30], int ghost[3], int target[2]);
