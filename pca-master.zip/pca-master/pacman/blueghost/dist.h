void dist (int pacman[3]);
