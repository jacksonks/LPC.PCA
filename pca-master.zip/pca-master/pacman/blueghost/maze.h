#define L 23
#define C 30

void print_maze (char maze[L][C]);
