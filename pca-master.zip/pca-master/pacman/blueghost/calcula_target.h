void calcula_target(char maze[23][30], int red[3],int pacman[3],int target[2]);
void verifica_target(char maze[23][30], int target[2]);
