void verifica_target(char maze[23][30], int target[2]);
