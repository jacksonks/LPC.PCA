void def_target_pink(char maze[L][C],int ghost[3],int pacman[3],int target[2]);
