
// a função pega a posição do pacman e insere no vetor target 

void blinky(int pacman[3], int target[2])
{
    target[0] = pacman[0]; // target x = pacman x
    target[1] = pacman[1]; // target y = pacman y  
}

