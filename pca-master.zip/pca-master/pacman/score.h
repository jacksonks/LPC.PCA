float score(int changes[3], int y_target,int x_target );
