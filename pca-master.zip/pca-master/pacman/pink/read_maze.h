#include <stdio.h> 
#define C 30
#define L 23

void read_maze (char maze[L][C]);

