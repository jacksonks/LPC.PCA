void partpackman (int *pacman,char maze[L][C]);
