void partghost (int *ghost,char maze[L][C]);
