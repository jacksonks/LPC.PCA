int partvariavel (int ghost_number);
