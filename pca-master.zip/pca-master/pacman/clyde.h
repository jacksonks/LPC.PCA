float distancia (int ghost[3], int pac[3]);
int clayde(int ghost[3],int pac[3]);
