#include "calcula_target.h"
void inky(int pacman[3], int red[3], int target[2])
{
       dist(pacman);
       calcula_target(red, pacman, target);
       verifica_target(maze, target);                         
}


