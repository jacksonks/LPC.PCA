void target_blinky(int pacman[3], int target[2]);

