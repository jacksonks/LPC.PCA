int busca_vetor(int vetor_possibilidades[2], int caminho[84][2],int t_vcaminho);
