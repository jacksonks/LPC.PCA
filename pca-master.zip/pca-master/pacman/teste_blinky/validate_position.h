#define C 30
#define L 23
int validate_position(char maze[L][C], int linha, int coluna);
