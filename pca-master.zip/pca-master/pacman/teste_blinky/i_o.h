void out(int id, int extra);
int in(int entrada); 

