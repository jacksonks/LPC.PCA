void verifica_direcao(char lab[23][30],int  cordenadas[2],int caminho[100][2],int tamanho,int x_pacman,int y_pacman);
