void change_path( char maze[23][30],int ghost[3], int target[2] );

