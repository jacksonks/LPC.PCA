void inky(int pacman[3], int red[3], int target[2]);
