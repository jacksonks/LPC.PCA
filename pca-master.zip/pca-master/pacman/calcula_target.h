void calcula_target(int red[3],int pacman[3],int target[2]);
