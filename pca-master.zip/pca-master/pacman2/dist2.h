void dist2 (int pacman[3]);
