#define C 30
#define L 23

void position(char maze[L][C], int numbers_player[3], char player);
