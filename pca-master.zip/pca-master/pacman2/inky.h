void inky(int pacman[3], int target[2], char maze[23][30]);
