int inverso(int *vetor, int s);
int select_sort(int *x);
void produto_escalar(int *vetor1,int *vetor2,int loops);
int teste_permutacao(int matriz[][100],int n,int m);
int verifica(int m,int n,int a[][100]);
void read_matrix(int m,int n,int a[][100]);
