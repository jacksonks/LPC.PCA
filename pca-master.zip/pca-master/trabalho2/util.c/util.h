float power(float x, float y);
int qtd_num(int num);
int is_perfect(int num);
float arctan(float x);
float alfa(float x, float y);
int serie_repetition(int n);
int is_higher(int x, int y);
int mdc (int x, int y);
int is_pair(int x);
int is_positive (int x);
int is_null(float x);
float biggest(float a, float b, float c);
int lower_number(int n1, int n2);
int fits(int a, int b);
int dice(); 
float lowest(float a, float b, float c);
int conta_digitos (unsigned long int num1, int num2 );

