float celsius (float x);
float farenheit (float x);
