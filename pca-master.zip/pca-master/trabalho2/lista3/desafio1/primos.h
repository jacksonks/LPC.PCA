int primos(int n);
