void cal_raizes (float x,float y,float z);

