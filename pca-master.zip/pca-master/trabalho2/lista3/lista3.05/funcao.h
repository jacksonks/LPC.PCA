int lower_number (int n1, int n2);
