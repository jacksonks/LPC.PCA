int lower_number(int n1, int n2)
{
	if (n1 > n2)
	{
		return n2;
	}
	else
	{
		return n1;
	}
}
