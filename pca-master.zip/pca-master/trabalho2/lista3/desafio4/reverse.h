int reverse(int n);
