/*Programacao de Computadores e Algoritmos / Laboratorio de Programacao de Computadores
 *
 * Trabalho 2
 * Lista 3
 * Questao 2
 *
 *\Equipe:  Elizabeth Castro
 *          Andreza Moreira
 *          Juliany Raiol
 *          Luana Andrade
 *          Wilson Neto
 *
 *
 * / */

#include <stdio.h>
	

int delta(int a, int b, int c)
{	

	return ((b*b)-(4*a*c));
	
}

	
