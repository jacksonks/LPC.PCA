/*
 * Programacao de Computadores e ALgoritmos
 * Trabalho 2
 * lista3.11.c
 *
 * Equipe:
 *
 *          Ewerton
 *          Hermann
 *          Jailson
 *          Lucas Botinelly
 *          Richardson
 *          Wilson Calisto 
 */
#include <stdio.h>
#include "calculation_tests.h"

int main(int argv, const char *argc[])
{
    calculation_tests();
    return 0;
}
