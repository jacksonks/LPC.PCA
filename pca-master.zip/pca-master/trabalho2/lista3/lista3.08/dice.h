int dice();
