
/* 
 * ===  FUNCTION  ======================================================================
 *         Name:  soma
 *  Description:  Esta função irá fazer a soma de três numeros
 * =====================================================================================
 */
float soma (float num1, float num2, float num3  ) //declarando as variaveis da função
{
	return  num1+num2+num3; 
}		/* -----  end of function soma  ----- */

