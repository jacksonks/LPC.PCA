/*
 * =====================================================================================
 *
 *       Filename:  soma.h
 *
 *    Description:  Cabeçalho da função soma
 *
 *        Version:  1.0
 *        Created:  11-09-2015 17:39:15
 *       Revision:  none
 *       Compiler:  gcc
 *
 *         Author:  YOUR NAME (), 
 *   Organization:  
 *
 * =====================================================================================
 */
float soma(float num1, float num2, float num3);
