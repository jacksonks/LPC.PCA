float valor_pagamento(float x,float y);
int div_cont(int x);
