void serie_repetition(int n);
