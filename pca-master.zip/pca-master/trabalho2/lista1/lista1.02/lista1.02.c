/* Programacao de computadores e algoritmos
 * Treabalho 2
 * lista1.02.c
 *
 * Equipe:
 *      Paulo Marinho
 *      Evandro Fernandes
 *      Jackson Gomes
 *      Rodrigo Oliveira
 *      Robson(TADS)
 *      Jessica (TADS)
 */


#include <stdio.h>
#include "p.h"


int main (int argc, const char *argv[])
{
    int n; /*  reduzindo o uso de variaveis desnecessarias */
    serie_repetition(n);
    return 0;
}
