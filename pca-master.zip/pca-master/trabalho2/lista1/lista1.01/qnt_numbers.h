
 int qnt_numbers (int num); 

