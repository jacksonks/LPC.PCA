#ifdef FUNCAO_H
#define FUNCAO_H

int is_hour(int);
int is_minute(int);
int convert_hour(int);
char am_pm(int);

#endif

