/* 
 *  Programação de Computadores e Algoritmos
 *  Trabalho 2
 *  Questão 1.8
 *  Equipe: Benjamin Borges
 *  Davi Tavares
 *  Paulo Henrique 
 *  Fernando Calderaro
 *  Lucas Frota
 *  Luiz Fernando
 *  
 *  a funcao "date" esta minuciosamente comentada em "funcao.c" na pasta lista1.11
 *  */
#include <stdio.h>
int main(int argc, const char *argv[])
{
	char num[12];
	printf(">");
	scanf("%s", num);
	data(num);
}
