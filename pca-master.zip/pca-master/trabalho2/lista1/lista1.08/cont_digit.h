int qtd_num(int num);

