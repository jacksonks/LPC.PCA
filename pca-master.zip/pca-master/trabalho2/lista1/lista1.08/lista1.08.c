/* 
 *  Programação de Computadores e Algoritmos
 *  Trabalho 2
 *  Questão 1.8
 *  Equipe: Benjamin Borges
 *  Davi Tavares
 *  Paulo Henrique 
 *  Fernando Calderaro
 *  Lucas Frota
 *  Luiz Fernando
 *  
 *  */
/* Este programa faz a contagem de digitos de um numero inteiro
 */
#include	<stdio.h>
int main ( int argc, char *argv[] )
{	
	int num;
	scanf ( "%d", &num );
	printf("Quantidades de  numeros é = %d\n", qtd_num(num));
	return 0;
}				/* ----------  end of function main  ---------- */
