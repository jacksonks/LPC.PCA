int rolldice (void);

