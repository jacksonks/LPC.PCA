int bloco (int n);
