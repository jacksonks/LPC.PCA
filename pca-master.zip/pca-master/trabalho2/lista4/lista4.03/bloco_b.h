int verificalinha (int vet[], int controle, int a);
