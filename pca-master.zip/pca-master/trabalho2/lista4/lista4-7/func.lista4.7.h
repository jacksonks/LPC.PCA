/*
 * =====================================================================================
 *
 *       Filename:  func.lista4.7.h
 *
 *    Description:  
 *
 *        Version:  1.0
 *        Created:  09-09-2015 13:13:06
 *       Revision:  none
 *       Compiler:  gcc
 *
 *         Author:  Richardson (), richardson.allan.souza@gmail.om
 *   Organization:  
 *
 * =====================================================================================
 */

float f1 (int x, int y);
