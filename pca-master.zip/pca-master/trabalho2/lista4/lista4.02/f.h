int fits(int a, int b);
int big(int num1, int num2);
int small(int num1, int num2);
