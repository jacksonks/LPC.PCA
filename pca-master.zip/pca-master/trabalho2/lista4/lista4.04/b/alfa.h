float alfa(float x, float y);
