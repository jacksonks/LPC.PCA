int fat(int n);
int calc_num(int n);
