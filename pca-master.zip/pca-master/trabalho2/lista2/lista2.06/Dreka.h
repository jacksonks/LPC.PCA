int idadedias(int anos, int meses, int dias);
