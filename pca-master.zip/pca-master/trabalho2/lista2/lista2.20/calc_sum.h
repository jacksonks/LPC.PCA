int calc_sum(int n);
