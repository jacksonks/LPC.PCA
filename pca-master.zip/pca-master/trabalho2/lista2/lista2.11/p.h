int tri_sort(int numero1,int numero2,int numero3);
