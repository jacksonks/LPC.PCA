#include <stdio.h>
void table(int n)
{

  int i;

  for(i=1;i<=n;i++)
  {
    printf("\t%d x %d = %d\n",i,n,i*n);
  }

}
