/*
 * Programação de Computadores e Algoritmos
 * Trabalho 2
 * Lista 2.18
 * Equipe: Benjamim Borges
 * Davi Tavares
 * Paulo Henrique
 * Fernando Calderaro
 * Lucas Frota
 * Luiz Fernando
 *
 * */

#include <stdio.h>


int main(){
	int numero;
	printf("Digite o número\n");
	scanf("%d",&numero);
	table(numero);
return 0;
}

