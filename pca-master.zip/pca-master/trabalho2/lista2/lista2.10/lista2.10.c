/*
 * Programacao de Computadores e ALgoritmos
 * Trabalho 2
 * lista2.10.c
 *
 * Equipe:
 *
 *          Ewerton
 *          Hermann
 *          Jailson
 *          Lucas Botinelly
 *          Richardson
 *          Wilson Calisto 
 */

#include <stdio.h>
#include "ideal_weight.h"
int main(int argv, const char *argc[])
{
    ideal_weight();
    return 0;
}
