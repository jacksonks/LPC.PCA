void ideal_weight();
