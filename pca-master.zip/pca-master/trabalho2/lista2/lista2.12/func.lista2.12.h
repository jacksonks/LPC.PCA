int check_values(int h1, int h2, int m1, int m2);
int dif_min(int m1, int m2);
int dif_hour(int h1, int h2, int m1, int m2);
