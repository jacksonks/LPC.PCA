int subtraction(int num1, int num2);
int sec_hours(int sec);
int sec_minutes(int sec);
