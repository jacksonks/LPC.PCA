int fat(int n);
