/*Programacao de Computadores e Algoritmos / Laboratorio de Programacao de Computadores
 *
 * Trabalho 2
 * Lista 2
 * Questao 16
 *
 *\Equipe:  Elizabeth Castro
 *          Andreza Moreira
 *          Juliany Raiol
 *          Luana Andrade
 *          Wilson Neto
 *
 */

#include <stdio.h>
#include "funcao.h"

int main()
{
    int numero;

    //recebe o numero do parametro
    printf("Digite o numero que deseja fazer o fatorial: ");
    scanf("%d", &numero);

     // coloca o numero recebido na funcao
    fatorial=fat(numero);
    // imprime a funcao
    printf("%d",fatorial);


    return 0
}
