int div_cont(int x);
