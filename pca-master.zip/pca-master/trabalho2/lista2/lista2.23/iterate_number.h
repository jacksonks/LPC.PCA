float iterate_number(int num);
