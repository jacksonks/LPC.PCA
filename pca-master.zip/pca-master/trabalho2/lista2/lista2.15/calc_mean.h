float calc_mean();
