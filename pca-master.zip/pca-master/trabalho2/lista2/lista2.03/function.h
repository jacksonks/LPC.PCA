int funcPrimo(int a);//Declaracao da funcao usada para fazer o link entre a funcao e main
