float bhaskara(float a, float b, float c);
