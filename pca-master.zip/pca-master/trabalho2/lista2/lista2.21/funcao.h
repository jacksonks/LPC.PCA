float iteracao(float a);
