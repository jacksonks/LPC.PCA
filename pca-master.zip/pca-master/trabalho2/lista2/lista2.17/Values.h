int greater_num(int maior,int num);
int smaller_num(int menor, int num);
