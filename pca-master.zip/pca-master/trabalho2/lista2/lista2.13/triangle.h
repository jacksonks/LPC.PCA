int triangle(float a, float b, float c); /* Protótipo da função triangle incluída em arquivo de cabeçalho */
