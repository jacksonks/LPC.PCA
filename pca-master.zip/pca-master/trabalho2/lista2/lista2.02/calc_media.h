


float media(float,float,float,char);// Declaracao da funcao usada para fazer o link entre a funcao e main



