int is_pos(int numero);
