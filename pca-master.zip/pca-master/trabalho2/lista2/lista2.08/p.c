int is_pos(int numero)
{
//essa função deverá retorna a verificação de positivo de um numero

    int boolean=0;
        if(numero>=0)
        {
           boolean=1;
        }
    return boolean;
}		   

