
int play_easy_bot(int vetor_posicao[9]);
