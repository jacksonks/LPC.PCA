int jogada_correta(int vetor_posicao[9],int i);
