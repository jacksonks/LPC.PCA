#define LINHA 3
#define COLUNA 3

void saida(int controle,int saida);
int entrada();
void mostra_matriz(int matriz[LINHA][COLUNA], char mprint[LINHA][COLUNA]);
int show_menu();
