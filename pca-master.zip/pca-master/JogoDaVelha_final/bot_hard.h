/* Implementado por Juliany, Evandro */

#include <stdio.h>

#define LINHA 3
#define COLUNA 3

int minimax(int m[LINHA][COLUNA], int player);

int movimento_bot(int posicao[LINHA][COLUNA]);
